package ��â��ȸ;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class MainPanel extends JPanel{
	// database module
	Database dbModule;
	// graphic
	Graphics g;
	// panels
	JPanel basePanel;
	JPanel leftSeats;
	JPanel centerSeats;
	JPanel rightInfo;
	JPanel topOrders;
	JPanel bottomStock;
	JPanel orderPanel;
	JPanel orderNTotalPricePanel;
	JPanel stockModifyPanel;
	// seat list
	ArrayList<JButton> seats = new ArrayList<JButton>();
	int seatArraySize;
	int halfSeatArraySize;
	// margin
	int framePanelMargin = 40;
	int mainGuiMargin = 40;
	int seatMargin = 50;
	int infoMargin = 0;
	int orderMargin = 3;
	// order info
	JList seatList = new JList();
	JList orderList = new JList();
	JList quantityList = new JList();
	JList priceList = new JList();
	JLabel totalPriceLabel;
	JButton orderAddButton = new JButton("�߰�");
	JButton orderRemoveButton = new JButton("���");
	JButton payButton = new JButton("����");
	JButton membershipButton = new JButton("�����");
	// stock info
	JList menuImageAndStockList = new JList();
	JScrollPane menuScrollPane;
	JButton stockAddButton = new JButton("�޴� �߰�");
	JButton stockModifyButton = new JButton("�޴� ����");
	JButton stockRemoveButton = new JButton("�޴� ����");
	JTextField stockAdder = new JTextField("");
	JButton stockAdderButton = new JButton("��� �߰�");
	//ImageIcon menuImage = new ImageIcon(location)
	int selectedSeat=1;
	String selectedMenuName;
	String selectedRemoveMenuName;
	// 
	orderButtonListener oBListener = new orderButtonListener();
	stockButtonListener sBListener = new stockButtonListener();

	MainPanel(){
		this.setBackground(Color.black);
		basePanel = new JPanel();
		basePanel.setPreferredSize(new Dimension(1400,840));
		basePanel.setBackground(Color.white);
		this.add(basePanel);

		dbModule = new Database();
		dbModule.dbConnectionInit();
		this.setUpGui();
	}

	// ����Ʈ �ڽ��� �׼��� �߻��ϸ� ó���ϴ� ������
	public class stockListListener implements ListSelectionListener {
		public void valueChanged(ListSelectionEvent lse) {					// ����Ʈ�� ������ �ٲ𶧸��� ȣ��
			if (!lse.getValueIsAdjusting() && !menuImageAndStockList.isSelectionEmpty()) {  // ���� ������ �� ���� ��쿡 ó��
				selectedMenuName = (String)menuImageAndStockList.getSelectedValue();
				selectedMenuName = selectedMenuName.substring(0,8);
				selectedMenuName = selectedMenuName.trim();
			}
		}
	}

	public class orderListListener implements ListSelectionListener {
		public void valueChanged(ListSelectionEvent lse) {					// ����Ʈ�� ������ �ٲ𶧸��� ȣ��
			if (!lse.getValueIsAdjusting() && !orderList.isSelectionEmpty()) {  // ���� ������ �� ���� ��쿡 ó��
				selectedRemoveMenuName = (String)orderList.getSelectedValue();
				selectedRemoveMenuName = selectedRemoveMenuName.trim();
			}
		}
	}

	public class seatClickListener implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			if(dbModule.isSeatEmpty(seats.indexOf(e.getSource())+1)) {
				int result = 0;
				result = JOptionPane.showConfirmDialog(null, "�ڸ��� ������ϴ�.\r\n�մ��� �������?");
				if(result == JOptionPane.NO_OPTION || result == JOptionPane.CANCEL_OPTION 
						|| result == JOptionPane.CLOSED_OPTION) {
					return;
				}
			}
			dbModule.startTRANSACTION();
			if(seats.get(selectedSeat-1)!=null) {
				seats.get(selectedSeat-1).setBorder(new EmptyBorder(10, 10,10, 10));
			}
			selectedSeat = seats.indexOf(e.getSource())+1;
			seats.get(selectedSeat-1).setBackground(Color.LIGHT_GRAY);
			seats.get(selectedSeat-1).setBorder(new LineBorder(Color.black));
			dbModule.setSeatFull(selectedSeat);
			dbModule.getOrderList(seatList, orderList, quantityList,priceList, selectedSeat);
			totalPriceLabel.setText(dbModule.getTotalPriceLabel(selectedSeat).getText());
			dbModule.doCOMMIT();
		}
	}

	//////////////////////////////////////// �ֹ� ��ư ������ //////////////////////////////////

	public class orderButtonListener implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			// �ֹ� �߰� ��ư
			if(e.getSource()==orderAddButton) {
				if(selectedMenuName==null) {
					JOptionPane.showMessageDialog(null, "�߰��� �޴��� �����ϼ���!");
					return;
				}
				int result = 0;

				try {
					result = Integer.parseInt(JOptionPane.showInputDialog(selectedMenuName+"�� �� �κ� �߰��ұ��?"));
				}catch (Exception ex) {
					return;
				}

				if(result>dbModule.getMenuStock(selectedMenuName)) {
					JOptionPane.showMessageDialog(null, selectedMenuName+"�� ����� �����մϴ�.");
					return;
				}
				else if(dbModule.isExistOrder(selectedSeat, selectedMenuName)) {
					dbModule.startTRANSACTION();
					dbModule.existOrderChange(selectedSeat, selectedMenuName, result);
					dbModule.updateMenuStock(selectedMenuName, -result);
				}
				else {
					dbModule.startTRANSACTION();
					dbModule.unExistOrderAdd(selectedSeat, selectedMenuName, result);	
					dbModule.updateMenuStock(selectedMenuName, -result);
				}		
			}

			// �ֹ� ��� ��ư
			else if(e.getSource()==orderRemoveButton) {
				if(selectedRemoveMenuName==null) {
					JOptionPane.showMessageDialog(null, "����� �޴��� �����ϼ���!");
					return;
				}
				int result = 0;
				try {
					result = Integer.parseInt(JOptionPane.showInputDialog(selectedRemoveMenuName+"�� �� �κ� ����ұ��?"));
				}catch (Exception ex) {
					return;
				}
				if(result>dbModule.getOrderQuantity(selectedSeat, selectedRemoveMenuName)) {
					JOptionPane.showMessageDialog(null, selectedRemoveMenuName+"�� �ֹ������� �� ���� ����� �� �����ϴ�.");
					return;
				}else if(result==dbModule.getOrderQuantity(selectedSeat, selectedRemoveMenuName)) {
					dbModule.startTRANSACTION();
					dbModule.cancelOrder(selectedSeat, selectedRemoveMenuName);
					dbModule.updateMenuStock(selectedRemoveMenuName, result);
				}else {
					dbModule.startTRANSACTION();
					dbModule.existOrderChange(selectedSeat, selectedRemoveMenuName, -result);
					dbModule.updateMenuStock(selectedRemoveMenuName, result);
				}		
			}

			// ���� ��ư
			else if(e.getSource()==payButton) {
				MainFrame.membershipModule.pay.setEnabled(true);
				
				if(dbModule.isSeatOrdered(selectedSeat)) {
					MainFrame.membershipModule.setPayment(selectedSeat);
					MainFrame.setMembershipVisible();
					//dbModule.doPayAndRecipt(selectedSeat);
					
				}
				else {
					dbModule.startTRANSACTION();
					dbModule.setSeatEmpty(selectedSeat);
					seats.get(selectedSeat-1).setBackground(new JButton().getBackground());
				}
			}
			else if(e.getSource()==membershipButton) {
				dbModule.startTRANSACTION();
				MainFrame.membershipModule.setPayment(-1);
				MainFrame.membershipModule.pay.setEnabled(false);
				MainFrame.setMembershipVisible();
			}

			dbModule.doCOMMIT();
			dbModule.getOrderList(seatList, orderList, quantityList,priceList, selectedSeat);
			dbModule.getStockInfo(menuImageAndStockList);
			totalPriceLabel.setText(dbModule.getTotalPriceLabel(selectedSeat).getText());
		}
	}

	///////////////////////////////////////��� ����â ��ư ������ ///////////////////////////

	public class stockButtonListener implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			// �޴� �߰� ��ư
			if(e.getSource()==stockAddButton) {
				String name;
				try {			
					name = (JOptionPane.showInputDialog("���ο� �޴��� �̸� �Է�"));
					name.length();
					if(dbModule.isExistMenu(name)){
						JOptionPane.showMessageDialog(null, "�̹� �����ϴ� �޴� �Դϴ�!");
						return;
					}
				}catch (Exception ex) {
					return;
				}

				int price = 0;
				try {
					price = Integer.parseInt(JOptionPane.showInputDialog("���ο� �޴��� ���� �Է�"));
				}
				catch (Exception ex) {
					return;
				}

				int stock = 0;
				try {
					stock = Integer.parseInt(JOptionPane.showInputDialog("���ο� �޴��� ��� �Է�"));
				}
				catch (Exception ex) {
					return;
				}

				dbModule.startTRANSACTION();
				dbModule.createNewStock(name,price,stock);
			}


			// �޴� ���� ��ư
			else if(e.getSource()==stockModifyButton) {
				if(selectedMenuName==null) {
					JOptionPane.showMessageDialog(null, "������ �޴��� �����ϼ���!");
					return;
				}

				String name = "";
				try {
					name = (JOptionPane.showInputDialog(selectedMenuName+"�� ���ο� �̸� �Է�"
							+ "\r\n(-1 �Է� �� ���� �̸��� ���� �˴ϴ�.)"));

					if(dbModule.isExistMenu(name)){
						JOptionPane.showMessageDialog(null, "�̹� �����ϴ� �޴� �Դϴ�!");
						return;
					}
					if(name.equals("-1")) {
						name = selectedMenuName;
					}
				}catch (Exception ex) {
					return;
				}

				int price = 0;
				try {
					price = Integer.parseInt(JOptionPane.showInputDialog(selectedMenuName+"�� ���ο� ���� �Է�"
							+ "\r\n(-1 �Է� �� ���� ������ ���� �˴ϴ�.)"));

					if(price==-1) {
						price = dbModule.getMenuPrice(selectedMenuName);
					}
				}
				catch (Exception ex) {
					return;
				}
				dbModule.startTRANSACTION();
				dbModule.modifyStock(price, selectedMenuName, name);
			}

			// �޴� ���� ��ư
			else if(e.getSource()==stockRemoveButton) {
				int result = 0;
				result = JOptionPane.showConfirmDialog(null, "�ش� �޴��� ��� ������ ������ϴ�!\r\n"
						+ "������ ���� �ұ��?");
				if(result == JOptionPane.NO_OPTION || result == JOptionPane.CANCEL_OPTION 
						|| result == JOptionPane.CLOSED_OPTION) {
					return;
				}
				else {
					dbModule.startTRANSACTION();
					dbModule.removeStock(selectedMenuName);
				}
			}

			else if(e.getSource()==stockAdderButton) {
				int add = Integer.parseInt(stockAdder.getText());
				if(selectedMenuName==null) {
					JOptionPane.showMessageDialog(null, "������ �޴��� �����ϼ���!");
					return;
				}
				else if((add*-1)>dbModule.getMenuStock(selectedMenuName)) {
					JOptionPane.showMessageDialog(null, selectedMenuName+"�� �� ��������� \r\n ���� ���� �� �����ϴ�!");
					return;
				}

				dbModule.startTRANSACTION();
				dbModule.addStock(selectedMenuName, add);
			}

			dbModule.doCOMMIT();
			dbModule.getOrderList(seatList, orderList, quantityList,priceList, selectedSeat);
			dbModule.getStockInfo(menuImageAndStockList);
			totalPriceLabel.setText(dbModule.getTotalPriceLabel(selectedSeat).getText());
		}
	}
	
	public void reGraphic(){
		for(int i=0; i<seatArraySize; i++) {
			if(!dbModule.isSeatEmpty(i+1)) {
				seats.get(i).setBackground(Color.LIGHT_GRAY);
				seats.get(i).setBorder(new EmptyBorder(10, 10,10, 10));
			}else {
				seats.get(i).setBackground(new JButton().getBackground());
				seats.get(i).setBorder(new EmptyBorder(10, 10,10, 10));
			}
		}
		dbModule.getOrderList(seatList, orderList, quantityList,priceList, selectedSeat);
		dbModule.getStockInfo(menuImageAndStockList);
	}

	/////////////////////////////////////////////GUI SETUP/////////////////////////////////////////////////
	void setUpGui() {
		dbModule.getStockInfo(menuImageAndStockList);
		seats = dbModule.getSeatList();
		dbModule.getOrderList(seatList, orderList, quantityList,priceList, selectedSeat);
		totalPriceLabel = dbModule.getTotalPriceLabel(selectedSeat);

		
		leftSeats = new JPanel(new GridLayout(halfSeatArraySize/2, 2, seatMargin, seatMargin));
		centerSeats = new JPanel(
				new GridLayout((halfSeatArraySize/2)+(halfSeatArraySize%2), 2, seatMargin, seatMargin));
		seatArraySize = seats.size();
		halfSeatArraySize = seatArraySize/2;
		// ���� �ڸ��� ���� �г�
		
		for(int i=0; i<halfSeatArraySize; i++) {
			if(!dbModule.isSeatEmpty(i+1)) {
				seats.get(i).setBackground(Color.LIGHT_GRAY);
				seats.get(i).setBorder(new EmptyBorder(10, 10,10, 10));
			}
			seats.get(i).addActionListener(new seatClickListener());
			leftSeats.add(seats.get(i));
		}
		
		// ��� �ڸ��� ���� �г�
	
		for(int i=0; i<halfSeatArraySize+(halfSeatArraySize%2); i++) {
			if(!dbModule.isSeatEmpty(i+halfSeatArraySize+1)) {
				seats.get(i+halfSeatArraySize).setBackground(Color.LIGHT_GRAY);
				seats.get(i+halfSeatArraySize).setBorder(new EmptyBorder(10, 10,10, 10));
			}
			seats.get(i+(halfSeatArraySize)).addActionListener(new seatClickListener());
			centerSeats.add(seats.get(i+(halfSeatArraySize)));
		}
		
		leftSeats.setBackground(null);
		centerSeats.setBackground(null);
		// ������ ����â�� ���� �г�
		rightInfo = new JPanel(new GridLayout(2,1,infoMargin,infoMargin));
		// ������ ��� �ֹ� �г�
		topOrders = new JPanel(new BorderLayout());
		topOrders.setBorder(new LineBorder(Color.black));
		topOrders.setBackground(null);	
		// "�ֹ� ���" ���̺�
		JLabel orderLabel = new JLabel("�ֹ� ���");
		orderLabel.setFont(new Font("����", Font.BOLD, 24));
		// �ֹ� ��� �г�
		orderPanel= new JPanel((new GridLayout(1, 4, orderMargin, orderMargin)));	
		orderPanel.setBackground(null);
		seatList.setEnabled(false);
		seatList.setBorder(new LineBorder(Color.black));
		orderList.setBorder(new LineBorder(Color.black));
		orderList.addListSelectionListener(new orderListListener());
		quantityList.setEnabled(false);
		quantityList.setBorder(new LineBorder(Color.black));
		priceList.setEnabled(false);
		priceList.setBorder(new LineBorder(Color.black));
		orderPanel.add(seatList);
		orderPanel.add(orderList);
		orderPanel.add(quantityList);
		orderPanel.add(priceList);
		// "�Ѱ�" ���̺�
		orderNTotalPricePanel = new JPanel(new BorderLayout());
		totalPriceLabel.setFont(new Font("����", Font.BOLD, 16));
		JPanel orderAddRemovePanel = new JPanel(new GridLayout(1, 3));
		orderAddButton.addActionListener(oBListener);
		orderRemoveButton.addActionListener(oBListener);
		payButton.addActionListener(oBListener);
		membershipButton.addActionListener(oBListener);
		orderAddRemovePanel.add(orderAddButton);
		orderAddRemovePanel.add(orderRemoveButton);
		orderAddRemovePanel.add(payButton);
		orderAddRemovePanel.add(membershipButton);
		orderNTotalPricePanel.add(orderAddRemovePanel,BorderLayout.WEST);
		orderNTotalPricePanel.add(totalPriceLabel,BorderLayout.EAST);
		// ������ ��� �ֹ� �г�
		topOrders.add(orderLabel,BorderLayout.NORTH);
		topOrders.add(orderPanel,BorderLayout.CENTER);
		topOrders.add(orderNTotalPricePanel,BorderLayout.SOUTH);

		// ������ �ϴ� ��� �г�
		bottomStock = new JPanel(new BorderLayout());
		bottomStock.setBorder(new LineBorder(Color.black));
		// "��� ����" ���̺�
		JLabel stockLabel = new JLabel("�޴�");
		stockLabel.setFont(new Font("����", Font.BOLD, 24));
		// ��� ��ũ�� ����
		menuScrollPane = new JScrollPane(menuImageAndStockList);
		menuImageAndStockList.setVisibleRowCount(7);
		menuImageAndStockList.setFixedCellWidth(400);
		menuImageAndStockList.setFixedCellHeight(40);
		menuImageAndStockList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		menuScrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		menuScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		menuImageAndStockList.addListSelectionListener(new stockListListener());
		// ��� ���� ��ư
		stockModifyPanel = new JPanel(new BorderLayout());
		JPanel stockPanel = new JPanel(new GridLayout(1,5));
		stockAddButton.addActionListener(sBListener);
		stockModifyButton.addActionListener(sBListener);
		stockRemoveButton.addActionListener(sBListener);
		stockAdderButton.addActionListener(sBListener);
		stockPanel.add(stockAddButton);
		stockPanel.add(stockModifyButton);
		stockPanel.add(stockRemoveButton);
		stockPanel.add(stockAdder);
		stockPanel.add(stockAdderButton);
		stockModifyPanel.add(stockPanel,BorderLayout.WEST);

		// ������ �ϴ� ��� �г�
		bottomStock.add(stockLabel, BorderLayout.NORTH);
		bottomStock.add(menuScrollPane, BorderLayout.CENTER);
		bottomStock.add(stockModifyPanel, BorderLayout.SOUTH);

		rightInfo.add(topOrders);
		rightInfo.add(bottomStock);
		// ������ ����â �г�
		basePanel.setLayout((new GridLayout(1,3,mainGuiMargin,mainGuiMargin)));
		basePanel.add(leftSeats);
		basePanel.add(centerSeats);
		basePanel.add(rightInfo);
		
	}

	public Database getdb(){
		return dbModule;
	}
}
