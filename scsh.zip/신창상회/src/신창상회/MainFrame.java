package ��â��ȸ;

import java.awt.Dimension;

import javax.swing.JFrame;

public class MainFrame extends JFrame {	
	static MembershipFrame membershipModule;
	static MainPanel guiModule;
	
	public static void main(String[] args) {
		MainFrame mainModule = new MainFrame();
		guiModule = new MainPanel();
		membershipModule = new MembershipFrame(guiModule.getdb());
		mainModule.setTitle("��â��ȸ");
		mainModule.setBounds(0,0, 1440, 900);
		mainModule.setResizable(false);
		mainModule.setDefaultCloseOperation(EXIT_ON_CLOSE);
		mainModule.add(guiModule);	
		mainModule.setVisible(true);
	}
	
	public static void setMembershipVisible() {
		membershipModule.setVisible(true);
	}
}
